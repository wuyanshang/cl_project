package com.example.ambiguity.config;

import com.example.ambiguity.model.AdamRecord;
import com.example.ambiguity.service.ReferenceDataLoader;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * A-RAG 分层检索工具。
 * 三个工具对应三种检索粒度，Agent 在推理过程中自主决定调用哪个。
 */
@Slf4j
@Configuration
@RequiredArgsConstructor
public class ReferenceSearchFunctions {

    private final ReferenceDataLoader loader;
    private final ObjectMapper objectMapper = new ObjectMapper();

    // ========== Tool 1: keyword_search ==========

    public record AdamKeywordSearchRequest(
            @JsonProperty("keyword")
            @JsonPropertyDescription("搜索关键词，如字段英文名、中文名关键词、或业务术语")
            String keyword,

            @JsonProperty("domain")
            @JsonPropertyDescription("业务领域过滤（可选），如 claim、policy、party、agency")
            String domain
    ) {}

    @Bean
    @Description("在ADaM公司数据模型中按关键词搜索保险标准术语。支持英文名精确/模糊匹配和中文关键词匹配。适合已知或能猜出关键词的场景。")
    public Function<AdamKeywordSearchRequest, String> keywordSearchAdam() {
        return request -> {
            try {
                if (!loader.isLoaded()) return "参考数据未加载";
                String keyword = request.keyword();
                if (keyword == null || keyword.isBlank()) return "请提供搜索关键词";

                List<AdamRecord> candidates = getCandidates(request.domain());
                List<Map<String, String>> results = new ArrayList<>();
                String kw = keyword.toLowerCase().replaceAll("[_\\-\\s]", "");

                for (AdamRecord rec : candidates) {
                    String attrEn = rec.getAttributeEn().replaceAll("[_\\-\\s]", "").toLowerCase();
                    if (attrEn.equals(kw)) {
                        results.add(formatRecord(rec, "exact_en"));
                    }
                }

                if (results.isEmpty()) {
                    String kwLower = keyword.toLowerCase();
                    for (AdamRecord rec : candidates) {
                        String attrEn = rec.getAttributeEn().toLowerCase();
                        String attrCn = rec.getAttributeCn() != null ? rec.getAttributeCn() : "";
                        if (attrEn.contains(kwLower) || kwLower.contains(attrEn)
                                || attrCn.contains(keyword)) {
                            results.add(formatRecord(rec, "fuzzy"));
                        }
                    }
                }

                if (results.isEmpty()) return "未找到与 '" + keyword + "' 相关的ADaM标准术语";
                if (results.size() > 5) results = results.subList(0, 5);

                log.debug("keywordSearchAdam: keyword='{}', domain='{}', hits={}", keyword, request.domain(), results.size());
                return objectMapper.writeValueAsString(results);
            } catch (Exception e) {
                log.warn("keywordSearchAdam 执行失败: {}", e.getMessage());
                return "检索失败: " + e.getMessage();
            }
        };
    }

    // ========== Tool 2: acord abbreviation lookup ==========

    public record AcordSearchRequest(
            @JsonProperty("term")
            @JsonPropertyDescription("要查找的缩写（如Amt、Clm）或完整单词（如Amount、Claim）")
            String term
    ) {}

    @Bean
    @Description("在ACORD保险行业国际标准缩写对照表中查找：输入缩写返回完整单词，输入完整单词返回标准缩写。适合字段英文名包含缩写需要解读的场景。")
    public Function<AcordSearchRequest, String> searchAcordAbbreviation() {
        return request -> {
            try {
                if (!loader.isLoaded()) return "参考数据未加载";
                String term = request.term();
                if (term == null || term.isBlank()) return "请提供要查找的缩写或单词";

                List<Map<String, String>> results = new ArrayList<>();

                loader.lookupByAbbr(term).ifPresent(word ->
                        results.add(Map.of("input", term, "type", "缩写→单词", "abbr", term, "word", word)));

                loader.lookupByWord(term).ifPresent(abbr ->
                        results.add(Map.of("input", term, "type", "单词→缩写", "word", term, "abbr", abbr)));

                if (results.isEmpty()) return "ACORD缩写表中未找到 '" + term + "'";

                log.debug("searchAcordAbbreviation: term='{}', hits={}", term, results.size());
                return objectMapper.writeValueAsString(results);
            } catch (Exception e) {
                log.warn("searchAcordAbbreviation 执行失败: {}", e.getMessage());
                return "检索失败: " + e.getMessage();
            }
        };
    }

    // ========== Tool 3: browse entity (chunk_read) ==========

    public record EntityBrowseRequest(
            @JsonProperty("entityName")
            @JsonPropertyDescription("要浏览的实体名称，如 Claim、Policy、Party")
            String entityName
    ) {}

    @Bean
    @Description("浏览ADaM数据模型中某个业务实体的全部标准属性字段列表。适合想了解某个实体（如Claim、Policy、Party）下有哪些标准字段的场景。")
    public Function<EntityBrowseRequest, String> browseAdamEntity() {
        return request -> {
            try {
                if (!loader.isLoaded()) return "参考数据未加载";
                String entityName = request.entityName();
                if (entityName == null || entityName.isBlank()) return "请提供实体名称";

                List<AdamRecord> matches = loader.getAllAdamRecords().stream()
                        .filter(r -> r.getEntity().equalsIgnoreCase(entityName))
                        .toList();

                if (matches.isEmpty()) {
                    matches = loader.getAdamByDomain(entityName.toLowerCase());
                }

                if (matches.isEmpty()) {
                    String available = loader.getAdamByDomain().keySet().stream()
                            .collect(Collectors.joining(", "));
                    return "未找到实体 '" + entityName + "'。可用的领域: " + available;
                }

                List<Map<String, String>> result = matches.stream()
                        .map(r -> formatRecord(r, "browse"))
                        .toList();

                log.debug("browseAdamEntity: entity='{}', fields={}", entityName, result.size());
                return objectMapper.writeValueAsString(result);
            } catch (Exception e) {
                log.warn("browseAdamEntity 执行失败: {}", e.getMessage());
                return "检索失败: " + e.getMessage();
            }
        };
    }

    // ========== helpers ==========

    private List<AdamRecord> getCandidates(String domain) {
        if (domain != null && !domain.isBlank()) {
            List<AdamRecord> domainRecords = loader.getAdamByDomain(domain.toLowerCase());
            if (!domainRecords.isEmpty()) {
                List<AdamRecord> all = new ArrayList<>(domainRecords);
                for (AdamRecord rec : loader.getAllAdamRecords()) {
                    if (!domainRecords.contains(rec)) all.add(rec);
                }
                return all;
            }
        }
        return loader.getAllAdamRecords();
    }

    private Map<String, String> formatRecord(AdamRecord rec, String matchType) {
        Map<String, String> map = new LinkedHashMap<>();
        map.put("entity", rec.getEntity());
        map.put("attribute_en", rec.getAttributeEn());
        map.put("attribute_cn", rec.getAttributeCn() != null ? rec.getAttributeCn() : "");
        map.put("attribute_definition", rec.getAttributeDefinition() != null ? rec.getAttributeDefinition() : "");
        map.put("match_type", matchType);
        return map;
    }
}
