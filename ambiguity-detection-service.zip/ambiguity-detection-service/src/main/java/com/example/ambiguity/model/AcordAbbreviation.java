package com.example.ambiguity.model;

import lombok.Data;

@Data
public class AcordAbbreviation {

    private String word;
    private String abbr;
}
