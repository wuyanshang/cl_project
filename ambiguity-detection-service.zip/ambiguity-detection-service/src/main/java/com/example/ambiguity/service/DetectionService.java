package com.example.ambiguity.service;

import com.example.ambiguity.model.AmbiguityResult;
import com.example.ambiguity.model.AssetField;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Service
public class DetectionService {

    private static final Pattern JSON_BLOCK_PATTERN =
            Pattern.compile("```json\\s*\\n([\\s\\S]*?)\\n\\s*```");

    private final ChatClient chatClient;
    private final ObjectMapper objectMapper;

    @Value("${ambiguity.max-retries:2}")
    private int maxRetries;

    @Value("${ambiguity.retry-delay-ms:2000}")
    private long retryDelayMs;

    public DetectionService(@Qualifier("detectionChatClient") ChatClient chatClient) {
        this.chatClient = chatClient;
        this.objectMapper = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /**
     * 对一个批次的数据调用 LLM 进行歧义检测，失败后自动重试（指数退避）。
     * system prompt 已在 ChatClient 构建时注入（SKILL.md 全文），这里只发 user message。
     */
    public List<AmbiguityResult> detectBatch(List<AssetField> batch, int batchIndex) {
        String batchText = formatBatchText(batch);
        log.info("批次 {} 开始检测，共 {} 条", batchIndex + 1, batch.size());

        Exception lastException = null;

        for (int attempt = 0; attempt <= maxRetries; attempt++) {
            if (attempt > 0) {
                long delay = retryDelayMs * (1L << (attempt - 1));
                log.warn("批次 {} 第 {} 次重试（等待 {}ms）...", batchIndex + 1, attempt, delay);
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }

            try {
                String response = chatClient.prompt()
                        .user(batchText)
                        .call()
                        .content();

                List<AmbiguityResult> results = parseResults(response);
                if (results.size() != batch.size()) {
                    log.warn("批次 {} 返回 {} 条结果，期望 {} 条", batchIndex + 1, results.size(), batch.size());
                    return padOrTruncate(results, batch.size());
                }

                if (attempt > 0) {
                    log.info("批次 {} 重试成功（第 {} 次尝试）", batchIndex + 1, attempt + 1);
                } else {
                    log.info("批次 {} 检测完成", batchIndex + 1);
                }
                return results;

            } catch (Exception e) {
                lastException = e;
                log.warn("批次 {} 第 {} 次尝试失败: {}", batchIndex + 1, attempt + 1, e.getMessage());
            }
        }

        log.error("批次 {} 在 {} 次尝试后仍然失败", batchIndex + 1, maxRetries + 1, lastException);
        return createErrorResults(batch.size(),
                "批次" + (batchIndex + 1) + "处理失败(已重试" + maxRetries + "次): "
                        + (lastException != null ? lastException.getMessage() : "未知错误"));
    }

    private String formatBatchText(List<AssetField> batch) {
        StringBuilder sb = new StringBuilder();
        sb.append("请对以下 ").append(batch.size()).append(" 条资产字段数据进行语义歧义检测：\n\n");

        for (int i = 0; i < batch.size(); i++) {
            AssetField f = batch.get(i);
            sb.append("--- 第 ").append(i + 1).append(" 条 ---\n");
            sb.append("系统英文名: ").append(nullToEmpty(f.getSystemEn())).append("\n");
            sb.append("系统中文名: ").append(nullToEmpty(f.getSystemCn())).append("\n");
            sb.append("表英文名: ").append(nullToEmpty(f.getTableEn())).append("\n");
            sb.append("表中文名: ").append(nullToEmpty(f.getTableCn())).append("\n");
            sb.append("字段英文名: ").append(nullToEmpty(f.getFieldEn())).append("\n");
            sb.append("字段中文名: ").append(nullToEmpty(f.getFieldCn())).append("\n\n");
        }

        return sb.toString();
    }

    private List<AmbiguityResult> parseResults(String response) throws Exception {
        String json = extractJson(response);
        return objectMapper.readValue(json, new TypeReference<>() {});
    }

    private String extractJson(String response) {
        Matcher matcher = JSON_BLOCK_PATTERN.matcher(response);
        if (matcher.find()) {
            return matcher.group(1).trim();
        }

        int start = response.indexOf('[');
        int end = response.lastIndexOf(']');
        if (start >= 0 && end > start) {
            return response.substring(start, end + 1);
        }

        return response;
    }

    private List<AmbiguityResult> padOrTruncate(List<AmbiguityResult> results, int expectedSize) {
        if (results.size() > expectedSize) {
            return results.subList(0, expectedSize);
        }
        List<AmbiguityResult> padded = new ArrayList<>(results);
        while (padded.size() < expectedSize) {
            padded.add(AmbiguityResult.error("[LLM 返回结果数量不足]"));
        }
        return padded;
    }

    private List<AmbiguityResult> createErrorResults(int size, String message) {
        List<AmbiguityResult> results = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            results.add(AmbiguityResult.error(message));
        }
        return results;
    }

    private String nullToEmpty(String value) {
        return value == null ? "" : value;
    }
}
