package com.example.ambiguity.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AdamRecord {

    private String entity;

    @JsonProperty("subject_area")
    private String subjectArea;

    @JsonProperty("entity_definition")
    private String entityDefinition;

    @JsonProperty("attribute_en")
    private String attributeEn;

    @JsonProperty("attribute_cn")
    private String attributeCn;

    @JsonProperty("attribute_definition")
    private String attributeDefinition;
}
