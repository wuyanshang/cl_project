package com.example.ambiguity.model;

import lombok.Data;

@Data
public class AssetField {

    private int rowIndex;
    private String systemEn;
    private String systemCn;
    private String tableEn;
    private String tableCn;
    private String fieldEn;
    private String fieldCn;
}
