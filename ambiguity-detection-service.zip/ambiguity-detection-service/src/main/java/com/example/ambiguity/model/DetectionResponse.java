package com.example.ambiguity.model;

import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
@Builder
public class DetectionResponse {

    private int total;
    private int ambiguousCount;
    private int noAmbiguityCount;
    private int errorCount;
    private Map<String, Integer> severityBreakdown;
    private Map<String, Integer> typeBreakdown;
    private String outputPath;
    private String message;
    private List<Integer> errorBatches;
}
