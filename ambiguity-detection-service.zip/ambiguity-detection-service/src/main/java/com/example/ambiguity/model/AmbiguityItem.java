package com.example.ambiguity.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AmbiguityItem {

    private String type;
    private String severity;
    private String detail;
    private String suggestion;

    @JsonProperty("recommended_en")
    private String recommendedEn;

    @JsonProperty("recommended_cn")
    private String recommendedCn;

    @JsonProperty("reference_source")
    private String referenceSource;
}
