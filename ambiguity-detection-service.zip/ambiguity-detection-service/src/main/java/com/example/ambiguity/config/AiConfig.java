package com.example.ambiguity.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.function.Function;

/**
 * 双 Agent 架构配置：
 * - 主 Agent（detectionChatClient）：歧义检测，SKILL = ambiguity-detection
 * - 子 Agent（subAgentClient）：术语检索，SKILL = terminology-search，拥有三个检索工具
 * - 主 Agent 通过 terminologySearch 函数调用子 Agent
 */
@Slf4j
@Configuration
public class AiConfig {

    /**
     * 子 Agent：术语检索专家。
     * 拥有三个检索工具（keywordSearchAdam / searchAcordAbbreviation / browseAdamEntity），
     * 在 ADaM 和 ACORD 参考资料中自主决定搜索策略。
     */
    @Bean("subAgentClient")
    public ChatClient subAgentClient(
            ChatModel chatModel,
            @Value("classpath:skills/terminology-search/SKILL.md") Resource skillResource) throws IOException {

        String skillContent = loadResource(skillResource);
        return ChatClient.builder(chatModel)
                .defaultSystem(skillContent)
                .defaultFunctions("keywordSearchAdam", "searchAcordAbbreviation", "browseAdamEntity")
                .build();
    }

    /**
     * 主 Agent：歧义检测专家。
     * 拥有一个工具（terminologySearch）用于调用子 Agent。
     * 仅在判定 A2 歧义时调用子 Agent。
     */
    @Bean("detectionChatClient")
    public ChatClient detectionChatClient(
            ChatModel chatModel,
            @Value("classpath:skills/ambiguity-detection/SKILL.md") Resource skillResource) throws IOException {

        String skillContent = loadResource(skillResource);
        return ChatClient.builder(chatModel)
                .defaultSystem(skillContent)
                .defaultFunctions("terminologySearch")
                .build();
    }

    // ========== 子 Agent 包装函数 ==========

    public record TerminologySearchRequest(
            @JsonProperty("system_en") @JsonPropertyDescription("系统英文名") String systemEn,
            @JsonProperty("system_cn") @JsonPropertyDescription("系统中文名") String systemCn,
            @JsonProperty("table_en") @JsonPropertyDescription("表英文名") String tableEn,
            @JsonProperty("table_cn") @JsonPropertyDescription("表中文名") String tableCn,
            @JsonProperty("field_en") @JsonPropertyDescription("字段英文名") String fieldEn,
            @JsonProperty("field_cn") @JsonPropertyDescription("字段中文名") String fieldCn
    ) {}

    /**
     * 将子 Agent 包装为一个 Function，供主 Agent 通过 function calling 调用。
     * 主 Agent 调用 terminologySearch() → 触发子 Agent 的完整 LLM 推理 → 子 Agent 内部调用检索工具 → 返回结果。
     */
    @Bean
    @Description("调用术语检索子Agent，在ADaM（公司数据模型）和ACORD（保险行业标准）参考资料中搜索标准术语。"
            + "子Agent拥有独立的检索工具和保险数据标准专业知识，会自主决定搜索策略。"
            + "传入字段的六维上下文信息，返回结构化的检索结果。仅在判定为A2歧义时调用。")
    public Function<TerminologySearchRequest, String> terminologySearch(
            @Qualifier("subAgentClient") ChatClient subAgentClient) {

        return request -> {
            try {
                String userMessage = String.format("""
                        请根据以下字段上下文信息，检索相关的标准术语：
                        
                        系统英文名: %s
                        系统中文名: %s
                        表英文名: %s
                        表中文名: %s
                        字段英文名: %s
                        字段中文名: %s
                        """,
                        safe(request.systemEn()),
                        safe(request.systemCn()),
                        safe(request.tableEn()),
                        safe(request.tableCn()),
                        safe(request.fieldEn()),
                        safe(request.fieldCn()));

                String result = subAgentClient.prompt()
                        .user(userMessage)
                        .call()
                        .content();

                log.info("子Agent检索完成: field_en={}, field_cn={}",
                        request.fieldEn(), request.fieldCn());
                return result;

            } catch (Exception e) {
                log.warn("子Agent检索失败: {}", e.getMessage());
                return "术语检索失败: " + e.getMessage();
            }
        };
    }

    private String loadResource(Resource resource) throws IOException {
        return new String(resource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }
}
