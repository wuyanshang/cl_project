package com.example.ambiguity.service;

import com.example.ambiguity.model.AcordAbbreviation;
import com.example.ambiguity.model.AdamRecord;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

@Slf4j
@Component
public class ReferenceDataLoader {

    @Value("${ambiguity.reference.adam-pattern:classpath:reference/adam/*.json}")
    private String adamPattern;

    @Value("${ambiguity.reference.acord-path:classpath:reference/acord_abbreviations.json}")
    private String acordPath;

    private final ObjectMapper objectMapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    @Getter
    private final Map<String, List<AdamRecord>> adamByDomain = new LinkedHashMap<>();

    @Getter
    private List<AdamRecord> allAdamRecords = new ArrayList<>();

    @Getter
    private List<AcordAbbreviation> acordAbbreviations = new ArrayList<>();

    private final Map<String, String> abbrLookup = new HashMap<>();
    private final Map<String, String> wordLookup = new HashMap<>();

    @PostConstruct
    public void init() {
        loadAdamData();
        loadAcordData();
        log.info("参考数据加载完成: ADaM {} 条 (来自 {} 个领域文件), ACORD 缩写 {} 条",
                allAdamRecords.size(), adamByDomain.size(), acordAbbreviations.size());
    }

    private void loadAdamData() {
        try {
            PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
            Resource[] resources = resolver.getResources(adamPattern);
            for (Resource resource : resources) {
                String filename = resource.getFilename();
                if (filename == null) continue;

                String domain = filename.replace(".json", "");
                try (InputStream is = resource.getInputStream()) {
                    List<AdamRecord> records = objectMapper.readValue(is, new TypeReference<>() {});
                    adamByDomain.put(domain, records);
                    allAdamRecords.addAll(records);
                    log.debug("加载 ADaM 领域 '{}': {} 条记录", domain, records.size());
                }
            }
        } catch (IOException e) {
            log.warn("加载 ADaM 数据失败（参考数据增强将不可用）: {}", e.getMessage());
        }
    }

    private void loadAcordData() {
        try {
            PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
            Resource resource = resolver.getResource(acordPath);
            if (resource.exists()) {
                try (InputStream is = resource.getInputStream()) {
                    acordAbbreviations = objectMapper.readValue(is, new TypeReference<>() {});
                    for (AcordAbbreviation a : acordAbbreviations) {
                        abbrLookup.put(a.getAbbr().toLowerCase(), a.getWord());
                        wordLookup.put(a.getWord().toLowerCase(), a.getAbbr());
                    }
                }
            }
        } catch (IOException e) {
            log.warn("加载 ACORD 缩写数据失败: {}", e.getMessage());
        }
    }

    /**
     * 根据缩写查完整单词（不区分大小写）
     */
    public Optional<String> lookupByAbbr(String abbr) {
        if (abbr == null) return Optional.empty();
        return Optional.ofNullable(abbrLookup.get(abbr.toLowerCase()));
    }

    /**
     * 根据完整单词查标准缩写（不区分大小写）
     */
    public Optional<String> lookupByWord(String word) {
        if (word == null) return Optional.empty();
        return Optional.ofNullable(wordLookup.get(word.toLowerCase()));
    }

    /**
     * 根据业务领域关键词获取对应的 ADaM 记录
     */
    public List<AdamRecord> getAdamByDomain(String domain) {
        return adamByDomain.getOrDefault(domain.toLowerCase(), List.of());
    }

    public boolean isLoaded() {
        return !allAdamRecords.isEmpty() || !acordAbbreviations.isEmpty();
    }
}
