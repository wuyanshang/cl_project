package com.example.ambiguity.service;

import com.example.ambiguity.model.AmbiguityItem;
import com.example.ambiguity.model.AmbiguityResult;
import com.example.ambiguity.model.AssetField;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ExcelService {

    private static final Map<String, String> COLUMN_ALIASES = Map.ofEntries(
            Map.entry("system_en", "systemEn"), Map.entry("系统英文名", "systemEn"), Map.entry("系统英文", "systemEn"),
            Map.entry("system_cn", "systemCn"), Map.entry("系统中文名", "systemCn"), Map.entry("系统中文", "systemCn"),
            Map.entry("table_en", "tableEn"), Map.entry("表英文名", "tableEn"), Map.entry("表英文", "tableEn"),
            Map.entry("table_cn", "tableCn"), Map.entry("表中文名", "tableCn"), Map.entry("表中文", "tableCn"),
            Map.entry("field_en", "fieldEn"), Map.entry("字段英文名", "fieldEn"), Map.entry("字段英文", "fieldEn"),
            Map.entry("field_cn", "fieldCn"), Map.entry("字段中文名", "fieldCn"), Map.entry("字段中文", "fieldCn")
    );

    private static final String[] RESULT_HEADERS = {
            "有歧义", "严重度", "歧义概述",
            "A1_中英文不匹配", "A2_字典歧义不完整",
            "推荐英文名", "推荐中文名", "参考来源", "消歧建议"
    };

    public List<AssetField> readExcel(String filePath) throws IOException {
        List<AssetField> records = new ArrayList<>();

        try (Workbook workbook = WorkbookFactory.create(Files.newInputStream(Path.of(filePath)))) {
            Sheet sheet = workbook.getSheetAt(0);
            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                throw new IllegalArgumentException("Excel 文件为空或没有表头行");
            }

            Map<String, Integer> columnMap = resolveColumnMapping(headerRow);
            log.info("列映射: {}", columnMap);

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                AssetField field = new AssetField();
                field.setRowIndex(i);
                field.setSystemEn(getCellValue(row, columnMap.get("systemEn")));
                field.setSystemCn(getCellValue(row, columnMap.get("systemCn")));
                field.setTableEn(getCellValue(row, columnMap.get("tableEn")));
                field.setTableCn(getCellValue(row, columnMap.get("tableCn")));
                field.setFieldEn(getCellValue(row, columnMap.get("fieldEn")));
                field.setFieldCn(getCellValue(row, columnMap.get("fieldCn")));
                records.add(field);
            }
        }

        log.info("共提取 {} 条数据", records.size());
        return records;
    }

    /**
     * 复制原 Excel，在末尾追加检测结果列，写入新文件。
     */
    public String writeResultExcel(String inputPath, List<AssetField> data,
                                   List<AmbiguityResult> results) throws IOException {
        String outputPath = generateOutputPath(inputPath);
        byte[] originalBytes = Files.readAllBytes(Path.of(inputPath));

        try (Workbook workbook = new XSSFWorkbook(new ByteArrayInputStream(originalBytes))) {
            Sheet sheet = workbook.getSheetAt(0);
            Row headerRow = sheet.getRow(0);
            int appendCol = headerRow.getLastCellNum();

            CellStyle headerStyle = createHeaderStyle(workbook);
            for (int i = 0; i < RESULT_HEADERS.length; i++) {
                Cell cell = headerRow.createCell(appendCol + i);
                cell.setCellValue(RESULT_HEADERS[i]);
                cell.setCellStyle(headerStyle);
            }

            for (int i = 0; i < data.size() && i < results.size(); i++) {
                Row row = sheet.getRow(data.get(i).getRowIndex());
                if (row == null) continue;

                AmbiguityResult r = results.get(i);
                row.createCell(appendCol).setCellValue(r.isHasAmbiguity() ? "是" : "否");
                row.createCell(appendCol + 1).setCellValue(r.getOverallSeverity());
                row.createCell(appendCol + 2).setCellValue(r.getSummary());
                row.createCell(appendCol + 3).setCellValue(joinByType(r, "A1"));
                row.createCell(appendCol + 4).setCellValue(joinByType(r, "A2"));
                row.createCell(appendCol + 5).setCellValue(joinA2Field(r, AmbiguityItem::getRecommendedEn));
                row.createCell(appendCol + 6).setCellValue(joinA2Field(r, AmbiguityItem::getRecommendedCn));
                row.createCell(appendCol + 7).setCellValue(joinA2Field(r, AmbiguityItem::getReferenceSource));
                row.createCell(appendCol + 8).setCellValue(joinSuggestions(r));
            }

            Files.createDirectories(Path.of(outputPath).getParent());
            try (FileOutputStream fos = new FileOutputStream(outputPath)) {
                workbook.write(fos);
            }
        }

        log.info("结果已写入: {}", outputPath);
        return outputPath;
    }

    private Map<String, Integer> resolveColumnMapping(Row headerRow) {
        Map<String, Integer> mapping = new HashMap<>();
        for (int i = 0; i < headerRow.getLastCellNum(); i++) {
            Cell cell = headerRow.getCell(i);
            if (cell == null) continue;
            String headerName = cell.getStringCellValue().trim();
            String fieldName = COLUMN_ALIASES.get(headerName);
            if (fieldName != null) {
                mapping.put(fieldName, i);
            }
        }
        return mapping;
    }

    private String getCellValue(Row row, Integer colIndex) {
        if (colIndex == null) return "";
        Cell cell = row.getCell(colIndex);
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue().trim();
            case NUMERIC -> String.valueOf((long) cell.getNumericCellValue());
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            default -> "";
        };
    }

    private String generateOutputPath(String inputPath) {
        Path path = Path.of(inputPath);
        String fileName = path.getFileName().toString();
        int dotIdx = fileName.lastIndexOf('.');
        String baseName = dotIdx > 0 ? fileName.substring(0, dotIdx) : fileName;
        String ext = dotIdx > 0 ? fileName.substring(dotIdx) : ".xlsx";
        return path.getParent().resolve(baseName + "_ambiguity_result" + ext).toString();
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        return style;
    }

    private String joinByType(AmbiguityResult result, String type) {
        if (result.getAmbiguities() == null) return "";
        return result.getAmbiguities().stream()
                .filter(a -> type.equals(a.getType()))
                .map(AmbiguityItem::getDetail)
                .filter(Objects::nonNull)
                .collect(Collectors.joining("; "));
    }

    private String joinA2Field(AmbiguityResult result, Function<AmbiguityItem, String> extractor) {
        if (result.getAmbiguities() == null) return "";
        return result.getAmbiguities().stream()
                .filter(a -> "A2".equals(a.getType()))
                .map(extractor)
                .filter(Objects::nonNull)
                .collect(Collectors.joining("; "));
    }

    private String joinSuggestions(AmbiguityResult result) {
        if (result.getAmbiguities() == null) return "";
        return result.getAmbiguities().stream()
                .map(AmbiguityItem::getSuggestion)
                .filter(Objects::nonNull)
                .collect(Collectors.joining("; "));
    }
}
