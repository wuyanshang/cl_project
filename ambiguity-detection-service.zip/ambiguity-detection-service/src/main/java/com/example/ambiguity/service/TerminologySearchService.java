package com.example.ambiguity.service;

import com.example.ambiguity.model.AcordAbbreviation;
import com.example.ambiguity.model.AdamRecord;
import com.example.ambiguity.model.AssetField;
import com.example.ambiguity.model.TerminologySearchResult;
import com.example.ambiguity.model.TerminologySearchResult.AdamMatch;
import com.example.ambiguity.model.TerminologySearchResult.AcordMatch;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 纯 Java 术语检索服务。
 * 在内存中的 ADaM/ACORD 参考数据里做确定性匹配，零 LLM 调用。
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TerminologySearchService {

    private final ReferenceDataLoader referenceData;

    private static final int MAX_RESULTS_PER_TYPE = 3;
    private static final int MAX_ENTITY_RELATED = 5;

    private static final Map<String, List<String>> DOMAIN_KEYWORDS = Map.of(
            "claim", List.of("理赔", "claim", "clm", "赔案", "报案", "出险", "索赔"),
            "policy", List.of("保单", "保全", "policy", "pol", "pos", "承保", "投保"),
            "party", List.of("客户", "当事人", "party", "人员", "被保人", "投保人", "受益人"),
            "agency", List.of("代理", "agency", "agent", "渠道", "中介")
    );

    private static final Pattern CAMEL_SPLIT = Pattern.compile("(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])");
    private static final Pattern SEPARATOR_SPLIT = Pattern.compile("[_\\-]");

    public TerminologySearchResult search(AssetField field) {
        if (!referenceData.isLoaded()) {
            log.debug("参考数据未加载，跳过术语检索");
            return TerminologySearchResult.empty();
        }

        String domain = detectDomain(field);
        List<AdamMatch> adamMatches = searchAdam(field, domain);
        List<AcordMatch> acordMatches = searchAcord(field.getFieldEn());

        TerminologySearchResult result = TerminologySearchResult.builder()
                .detectedDomain(domain)
                .adamMatches(adamMatches)
                .acordMatches(acordMatches)
                .build();

        log.debug("术语检索完成: field_en={}, domain={}, adam={}, acord={}",
                field.getFieldEn(), domain, adamMatches.size(), acordMatches.size());
        return result;
    }

    /**
     * 根据系统名、表名等上下文推断业务领域
     */
    String detectDomain(AssetField field) {
        String context = String.join(" ",
                nullToEmpty(field.getSystemEn()),
                nullToEmpty(field.getSystemCn()),
                nullToEmpty(field.getTableEn()),
                nullToEmpty(field.getTableCn())
        ).toLowerCase();

        for (Map.Entry<String, List<String>> entry : DOMAIN_KEYWORDS.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (context.contains(keyword.toLowerCase())) {
                    return entry.getKey();
                }
            }
        }
        return null;
    }

    /**
     * 在 ADaM 中搜索，按精确→模糊→中文关键词→entity级别的优先级
     */
    List<AdamMatch> searchAdam(AssetField field, String domain) {
        List<AdamRecord> candidates = getCandidateRecords(domain);
        if (candidates.isEmpty()) return List.of();

        String fieldEn = nullToEmpty(field.getFieldEn()).toLowerCase();
        String fieldCn = nullToEmpty(field.getFieldCn());
        String normalizedEn = normalize(fieldEn);

        List<AdamMatch> results = new ArrayList<>();

        for (AdamRecord rec : candidates) {
            String attrEn = normalize(nullToEmpty(rec.getAttributeEn()).toLowerCase());
            if (attrEn.equals(normalizedEn)) {
                results.add(toAdamMatch(rec, "exact_en"));
            }
        }
        if (results.size() >= MAX_RESULTS_PER_TYPE) return trim(results);

        Set<String> fieldTokens = tokenize(fieldEn);
        for (AdamRecord rec : candidates) {
            String attrEn = nullToEmpty(rec.getAttributeEn()).toLowerCase();
            Set<String> attrTokens = tokenize(attrEn);
            if (hasOverlap(fieldTokens, attrTokens) && !isAlreadyMatched(results, rec)) {
                results.add(toAdamMatch(rec, "fuzzy_en"));
            }
        }
        if (results.size() >= MAX_RESULTS_PER_TYPE) return trim(results);

        if (!fieldCn.isEmpty()) {
            for (AdamRecord rec : candidates) {
                String attrCn = nullToEmpty(rec.getAttributeCn());
                if (!attrCn.isEmpty() && hasCnOverlap(fieldCn, attrCn) && !isAlreadyMatched(results, rec)) {
                    results.add(toAdamMatch(rec, "keyword_cn"));
                }
            }
        }
        if (results.size() >= MAX_RESULTS_PER_TYPE) return trim(results);

        if (results.isEmpty() && domain != null) {
            List<AdamRecord> domainRecords = referenceData.getAdamByDomain(domain);
            int count = 0;
            for (AdamRecord rec : domainRecords) {
                if (count >= MAX_ENTITY_RELATED) break;
                if (!isAlreadyMatched(results, rec)) {
                    results.add(toAdamMatch(rec, "entity_related"));
                    count++;
                }
            }
        }

        return results;
    }

    /**
     * 在 ACORD 缩写表中搜索
     */
    List<AcordMatch> searchAcord(String fieldEn) {
        if (fieldEn == null || fieldEn.isEmpty()) return List.of();

        Set<String> segments = tokenize(fieldEn.toLowerCase());
        List<AcordMatch> results = new ArrayList<>();
        Set<String> seen = new HashSet<>();

        for (AcordAbbreviation entry : referenceData.getAcordAbbreviations()) {
            String abbrLower = entry.getAbbr().toLowerCase();
            String wordLower = entry.getWord().toLowerCase();

            for (String seg : segments) {
                if ((seg.equals(abbrLower) || seg.equals(wordLower)) && seen.add(abbrLower)) {
                    results.add(AcordMatch.builder()
                            .word(entry.getWord())
                            .abbr(entry.getAbbr())
                            .build());
                }
            }
        }
        return results;
    }

    private List<AdamRecord> getCandidateRecords(String domain) {
        if (domain != null) {
            List<AdamRecord> domainRecords = referenceData.getAdamByDomain(domain);
            if (!domainRecords.isEmpty()) {
                List<AdamRecord> all = new ArrayList<>(domainRecords);
                for (AdamRecord rec : referenceData.getAllAdamRecords()) {
                    if (!domainRecords.contains(rec)) {
                        all.add(rec);
                    }
                }
                return all;
            }
        }
        return referenceData.getAllAdamRecords();
    }

    private Set<String> tokenize(String name) {
        if (name == null || name.isEmpty()) return Set.of();
        String withSeparators = CAMEL_SPLIT.matcher(name).replaceAll("_");
        return Arrays.stream(SEPARATOR_SPLIT.split(withSeparators))
                .map(String::toLowerCase)
                .filter(s -> s.length() >= 2)
                .collect(Collectors.toSet());
    }

    private boolean hasOverlap(Set<String> a, Set<String> b) {
        for (String token : a) {
            if (b.contains(token)) return true;
            for (String bToken : b) {
                if (token.contains(bToken) || bToken.contains(token)) return true;
            }
        }
        return false;
    }

    private boolean hasCnOverlap(String fieldCn, String attrCn) {
        if (fieldCn.length() <= 1 || attrCn.length() <= 1) return false;
        return attrCn.contains(fieldCn) || fieldCn.contains(attrCn);
    }

    private String normalize(String s) {
        return s.replaceAll("[_\\-\\s]", "").toLowerCase();
    }

    private AdamMatch toAdamMatch(AdamRecord rec, String matchType) {
        return AdamMatch.builder()
                .entity(rec.getEntity())
                .attributeEn(rec.getAttributeEn())
                .attributeCn(rec.getAttributeCn())
                .attributeDefinition(rec.getAttributeDefinition())
                .matchType(matchType)
                .build();
    }

    private boolean isAlreadyMatched(List<AdamMatch> results, AdamRecord rec) {
        return results.stream().anyMatch(m ->
                m.getAttributeEn().equals(rec.getAttributeEn()) &&
                m.getEntity().equals(rec.getEntity()));
    }

    private List<AdamMatch> trim(List<AdamMatch> results) {
        return results.size() > MAX_RESULTS_PER_TYPE
                ? results.subList(0, MAX_RESULTS_PER_TYPE) : results;
    }

    private String nullToEmpty(String s) {
        return s == null ? "" : s;
    }
}
