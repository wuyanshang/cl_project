package com.example.ambiguity.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TerminologySearchResult {

    private String detectedDomain;
    private List<AdamMatch> adamMatches;
    private List<AcordMatch> acordMatches;

    public static TerminologySearchResult empty() {
        return TerminologySearchResult.builder()
                .adamMatches(List.of())
                .acordMatches(List.of())
                .build();
    }

    public boolean hasAdamMatch() {
        return adamMatches != null && !adamMatches.isEmpty();
    }

    public boolean hasAcordMatch() {
        return acordMatches != null && !acordMatches.isEmpty();
    }

    public boolean isEmpty() {
        return !hasAdamMatch() && !hasAcordMatch();
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AdamMatch {
        private String entity;
        private String attributeEn;
        private String attributeCn;
        private String attributeDefinition;
        private String matchType;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AcordMatch {
        private String word;
        private String abbr;
    }
}
