package com.example.ambiguity.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class AmbiguityResult {

    private int index;

    @JsonProperty("has_ambiguity")
    private boolean hasAmbiguity;

    private List<AmbiguityItem> ambiguities = new ArrayList<>();

    @JsonProperty("overall_severity")
    private String overallSeverity;

    private String summary;

    public static AmbiguityResult error(String message) {
        AmbiguityResult result = new AmbiguityResult();
        result.setHasAmbiguity(false);
        result.setOverallSeverity("ERROR");
        result.setSummary(message);
        return result;
    }
}
