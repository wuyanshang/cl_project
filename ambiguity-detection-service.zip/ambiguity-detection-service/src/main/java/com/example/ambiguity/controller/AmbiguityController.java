package com.example.ambiguity.controller;

import com.example.ambiguity.model.DetectionResponse;
import com.example.ambiguity.service.AmbiguityOrchestrator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Slf4j
@RestController
@RequestMapping("/api/ambiguity")
@RequiredArgsConstructor
public class AmbiguityController {

    private final AmbiguityOrchestrator orchestrator;

    /**
     * 通过服务器上的文件路径触发检测
     */
    @PostMapping("/detect")
    public ResponseEntity<DetectionResponse> detect(
            @RequestParam String inputPath,
            @RequestParam(defaultValue = "10") int batchSize) throws IOException {

        DetectionResponse response = orchestrator.process(inputPath, batchSize);
        return ResponseEntity.ok(response);
    }

    /**
     * 通过上传 Excel 文件触发检测
     */
    @PostMapping("/detect/upload")
    public ResponseEntity<DetectionResponse> detectByUpload(
            @RequestParam("file") MultipartFile file,
            @RequestParam(defaultValue = "10") int batchSize) throws IOException {

        String originalName = file.getOriginalFilename();
        String suffix = originalName != null && originalName.contains(".")
                ? originalName.substring(originalName.lastIndexOf('.')) : ".xlsx";

        Path tempFile = Files.createTempFile("ambiguity_input_", suffix);
        file.transferTo(tempFile);
        log.info("上传文件已保存到临时路径: {}", tempFile);

        try {
            DetectionResponse response = orchestrator.process(tempFile.toString(), batchSize);
            return ResponseEntity.ok(response);
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }
}
