package com.example.ambiguity.service;

import com.example.ambiguity.model.*;
import com.example.ambiguity.model.TerminologySearchResult.AdamMatch;
import com.example.ambiguity.model.TerminologySearchResult.AcordMatch;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class AmbiguityOrchestrator {

    private final ExcelService excelService;
    private final DetectionService detectionService;
    private final TerminologySearchService terminologySearchService;

    @Value("${ambiguity.default-batch-size:10}")
    private int defaultBatchSize;

    @Value("${ambiguity.max-concurrency:5}")
    private int maxConcurrency;

    @Value("${ambiguity.terminology-search.enabled:true}")
    private boolean terminologySearchEnabled;

    public DetectionResponse process(String inputPath, int batchSize) throws IOException {
        if (batchSize <= 0) {
            batchSize = defaultBatchSize;
        }

        List<AssetField> allData = excelService.readExcel(inputPath);
        List<List<AssetField>> batches = splitBatches(allData, batchSize);
        log.info("共 {} 条数据，分为 {} 个批次（每批 {} 条），并发数 {}",
                allData.size(), batches.size(), batchSize, maxConcurrency);

        List<AmbiguityResult> allResults = executeParallelDetection(batches);

        if (terminologySearchEnabled) {
            enrichA2WithReferenceData(allData, allResults);
        }

        String outputPath = excelService.writeResultExcel(inputPath, allData, allResults);

        return buildResponse(allResults, outputPath);
    }

    private List<AmbiguityResult> executeParallelDetection(List<List<AssetField>> batches) {
        ExecutorService executor = Executors.newFixedThreadPool(
                Math.min(maxConcurrency, batches.size()));

        try {
            List<CompletableFuture<List<AmbiguityResult>>> futures = new ArrayList<>();
            for (int i = 0; i < batches.size(); i++) {
                final int idx = i;
                final List<AssetField> batch = batches.get(i);
                futures.add(CompletableFuture.supplyAsync(
                        () -> detectionService.detectBatch(batch, idx), executor));
            }

            List<AmbiguityResult> allResults = new ArrayList<>();
            for (int i = 0; i < futures.size(); i++) {
                try {
                    allResults.addAll(futures.get(i).join());
                } catch (Exception e) {
                    log.error("批次 {} 异常: {}", i + 1, e.getMessage());
                    for (int j = 0; j < batches.get(i).size(); j++) {
                        allResults.add(AmbiguityResult.error("[批次" + (i + 1) + "处理异常]"));
                    }
                }
            }
            return allResults;
        } finally {
            executor.shutdown();
        }
    }

    /**
     * A2 后处理安全网：对 Agent 未通过工具获取标准来源的 A2 条目，
     * 用 Java 确定性检索做兜底增强。
     * Agent 已通过工具设置了 ADaM/ACORD 来源的条目会被跳过。
     */
    private void enrichA2WithReferenceData(List<AssetField> allData, List<AmbiguityResult> allResults) {
        int agentEnriched = 0;
        int javaEnriched = 0;

        for (int i = 0; i < allResults.size(); i++) {
            AmbiguityResult result = allResults.get(i);
            if (!result.isHasAmbiguity() || result.getAmbiguities() == null) continue;

            List<AmbiguityItem> a2Items = result.getAmbiguities().stream()
                    .filter(item -> "A2".equals(item.getType()))
                    .toList();
            if (a2Items.isEmpty()) continue;

            AssetField field = allData.get(i);

            for (AmbiguityItem item : a2Items) {
                String source = item.getReferenceSource();
                if (source != null && !source.contains("AI推理")) {
                    agentEnriched++;
                    continue;
                }

                TerminologySearchResult searchResult = terminologySearchService.search(field);
                if (!searchResult.isEmpty() && applyReferenceMatch(item, searchResult)) {
                    javaEnriched++;
                }
            }
        }

        log.info("A2 增强统计: Agent工具已处理 {} 条, Java兜底增强 {} 条",
                agentEnriched, javaEnriched);
    }

    /**
     * 将参考数据匹配结果应用到 A2 项目上。
     * 优先级: ADaM exact > ADaM fuzzy > ADaM keyword_cn > ACORD 缩写组合
     * 返回 true 表示成功用参考数据覆盖了 AI 的推荐。
     */
    private boolean applyReferenceMatch(AmbiguityItem item, TerminologySearchResult searchResult) {
        if (searchResult.hasAdamMatch()) {
            AdamMatch best = pickBestAdamMatch(searchResult.getAdamMatches());
            if (best != null && !"entity_related".equals(best.getMatchType())) {
                item.setRecommendedEn(best.getAttributeEn());
                item.setRecommendedCn(best.getAttributeCn());
                item.setReferenceSource("ADaM - " + best.getEntity() + "实体");

                String enhancedDetail = item.getDetail();
                if (enhancedDetail != null && !enhancedDetail.contains("ADaM")) {
                    enhancedDetail += String.format("（ADaM标准: %s/%s - %s）",
                            best.getEntity(), best.getAttributeEn(), best.getAttributeCn());
                    item.setDetail(enhancedDetail);
                }
                return true;
            }
        }

        if (searchResult.hasAcordMatch()) {
            List<AcordMatch> matches = searchResult.getAcordMatches();
            if (!matches.isEmpty()) {
                String acordRef = matches.stream()
                        .map(m -> m.getAbbr() + "=" + m.getWord())
                        .collect(Collectors.joining(", "));

                String currentSource = item.getReferenceSource();
                if (currentSource == null || currentSource.contains("AI推理")) {
                    item.setReferenceSource("ACORD标准缩写 (" + acordRef + ")");

                    String enhancedDetail = item.getDetail();
                    if (enhancedDetail != null && !enhancedDetail.contains("ACORD")) {
                        enhancedDetail += String.format("（ACORD缩写: %s）", acordRef);
                        item.setDetail(enhancedDetail);
                    }
                    return true;
                }
            }
        }

        return false;
    }

    private AdamMatch pickBestAdamMatch(List<AdamMatch> matches) {
        List<String> priority = List.of("exact_en", "fuzzy_en", "keyword_cn", "entity_related");
        for (String type : priority) {
            for (AdamMatch match : matches) {
                if (type.equals(match.getMatchType())) return match;
            }
        }
        return matches.isEmpty() ? null : matches.get(0);
    }

    private DetectionResponse buildResponse(List<AmbiguityResult> results, String outputPath) {
        int ambiguous = 0, noAmbiguity = 0, errorCount = 0;
        Map<String, Integer> severityMap = new LinkedHashMap<>();
        Map<String, Integer> typeMap = new LinkedHashMap<>();
        List<Integer> errorBatches = new ArrayList<>();

        for (AmbiguityResult r : results) {
            if ("ERROR".equals(r.getOverallSeverity())) {
                errorCount++;
                continue;
            }
            if (r.isHasAmbiguity()) {
                ambiguous++;
                severityMap.merge(r.getOverallSeverity(), 1, Integer::sum);
                if (r.getAmbiguities() != null) {
                    for (AmbiguityItem item : r.getAmbiguities()) {
                        typeMap.merge(item.getType(), 1, Integer::sum);
                    }
                }
            } else {
                noAmbiguity++;
            }
        }

        String message = String.format(
                "检测完成: 总计 %d 条, 有歧义 %d 条(%.1f%%), 无歧义 %d 条, 错误 %d 条",
                results.size(), ambiguous,
                results.isEmpty() ? 0 : ambiguous * 100.0 / results.size(),
                noAmbiguity, errorCount);
        log.info(message);

        return DetectionResponse.builder()
                .total(results.size())
                .ambiguousCount(ambiguous)
                .noAmbiguityCount(noAmbiguity)
                .errorCount(errorCount)
                .severityBreakdown(severityMap)
                .typeBreakdown(typeMap)
                .outputPath(outputPath)
                .errorBatches(errorBatches)
                .message(message)
                .build();
    }

    private <T> List<List<T>> splitBatches(List<T> list, int batchSize) {
        List<List<T>> batches = new ArrayList<>();
        for (int i = 0; i < list.size(); i += batchSize) {
            batches.add(list.subList(i, Math.min(i + batchSize, list.size())));
        }
        return batches;
    }
}
