package com.example.ambiguity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmbiguityDetectionApplication {

    public static void main(String[] args) {
        SpringApplication.run(AmbiguityDetectionApplication.class, args);
    }
}
